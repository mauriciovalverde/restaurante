import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Salad,
  Beef,
  Wheat,
  Milk,
  Soup,
  Wine,
  Sparkles,
  PackageOpen,
  ShoppingCart,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";

const categories = [
  {
    id: "hortalicas",
    name: "Hortaliças",
    icon: Salad,
    color: "from-green-500 to-emerald-600",
    bgColor: "bg-green-50",
    borderColor: "border-green-200",
  },
  {
    id: "proteinas",
    name: "Proteínas",
    icon: Beef,
    color: "from-red-500 to-rose-600",
    bgColor: "bg-red-50",
    borderColor: "border-red-200",
  },
  {
    id: "cereais",
    name: "Cereais",
    icon: Wheat,
    color: "from-amber-500 to-orange-600",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-200",
  },
  {
    id: "laticinios",
    name: "Laticínios",
    icon: Milk,
    color: "from-blue-500 to-cyan-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
  },
  {
    id: "temperos",
    name: "Temperos",
    icon: Soup,
    color: "from-yellow-500 to-amber-600",
    bgColor: "bg-yellow-50",
    borderColor: "border-yellow-200",
  },
  {
    id: "bebidas",
    name: "Bebidas",
    icon: Wine,
    color: "from-purple-500 to-violet-600",
    bgColor: "bg-purple-50",
    borderColor: "border-purple-200",
  },
  {
    id: "limpeza",
    name: "Limpeza",
    icon: Sparkles,
    color: "from-teal-500 to-cyan-600",
    bgColor: "bg-teal-50",
    borderColor: "border-teal-200",
  },
  {
    id: "descartaveis",
    name: "Descartáveis",
    icon: PackageOpen,
    color: "from-slate-500 to-gray-600",
    bgColor: "bg-slate-50",
    borderColor: "border-slate-200",
  },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            Bem-vindo ao Painel de Compras
          </h1>
          <p className="text-gray-600 text-lg">
            Selecione uma categoria para solicitar produtos
          </p>
        </motion.div>

        {/* Quick Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Link to={createPageUrl("PurchaseRequests")}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Button
                variant="outline"
                className="w-full h-20 text-lg font-semibold hover:bg-orange-50 hover:border-orange-300 transition-all"
              >
                <ShoppingCart className="w-6 h-6 mr-3 text-orange-600" />
                Ver Pedidos Pendentes
                <ArrowRight className="w-5 h-5 ml-auto text-gray-400" />
              </Button>
            </motion.div>
          </Link>

          <Link to={createPageUrl("CompletedPurchases")}>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Button
                variant="outline"
                className="w-full h-20 text-lg font-semibold hover:bg-green-50 hover:border-green-300 transition-all"
              >
                <CheckCircle2 className="w-6 h-6 mr-3 text-green-600" />
                Ver Compras Concluídas
                <ArrowRight className="w-5 h-5 ml-auto text-gray-400" />
              </Button>
            </motion.div>
          </Link>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {categories.map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + index * 0.05 }}
            >
              <Link to={`${createPageUrl("ProductList")}?category=${category.id}`}>
                <div
                  className={`relative overflow-hidden rounded-2xl border-2 ${category.borderColor} ${category.bgColor} 
                  hover:shadow-2xl hover:scale-105 transition-all duration-300 cursor-pointer group h-full`}
                >
                  <div className="p-6 md:p-8 flex flex-col items-center justify-center text-center min-h-[180px] md:min-h-[220px]">
                    <div
                      className={`w-16 h-16 md:w-20 md:h-20 rounded-xl bg-gradient-to-br ${category.color} 
                      flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                    >
                      <category.icon className="w-8 h-8 md:w-10 md:h-10 text-white" />
                    </div>
                    <h3 className="text-lg md:text-xl font-bold text-gray-900">
                      {category.name}
                    </h3>
                  </div>
                  
                  {/* Decorative element */}
                  <div className={`absolute -bottom-2 -right-2 w-20 h-20 bg-gradient-to-br ${category.color} rounded-full opacity-10`} />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}