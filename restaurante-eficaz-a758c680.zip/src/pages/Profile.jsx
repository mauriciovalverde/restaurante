import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Shield, Lock, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Profile() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data) => {
      // Base44 não permite mudança de senha via API do frontend por segurança
      // Usuário deve usar o fluxo de "Esqueci minha senha"
      throw new Error("Para alterar sua senha, use a opção 'Esqueci minha senha' na tela de login.");
    },
    onSuccess: () => {
      setShowSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      
      setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
    },
  });

  const handleChangePassword = (e) => {
    e.preventDefault();

    if (newPassword.length < 6) {
      alert("A nova senha deve ter no mínimo 6 caracteres.");
      return;
    }

    if (newPassword !== confirmPassword) {
      alert("A confirmação da senha não confere.");
      return;
    }

    changePasswordMutation.mutate({
      current_password: currentPassword,
      new_password: newPassword,
    });
  };

  const nivelAcessoLabels = {
    admin: "Administrador",
    coordenador: "Coordenador",
    parceiro: "Parceiro",
    visualizador: "Visualizador",
  };

  const nivelAcessoColors = {
    admin: "bg-purple-100 text-purple-800 border-purple-200",
    coordenador: "bg-blue-100 text-blue-800 border-blue-200",
    parceiro: "bg-green-100 text-green-800 border-green-200",
    visualizador: "bg-gray-100 text-gray-800 border-gray-200",
  };

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Meu Perfil</h1>
          <p className="text-gray-600">Gerencie suas informações pessoais</p>
        </motion.div>

        {/* Informações do Usuário */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5 text-orange-600" />
                Informações Pessoais
              </CardTitle>
              <CardDescription>
                Seus dados cadastrais no sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-gray-500">Nome Completo</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <User className="w-4 h-4 text-gray-400" />
                    <p className="font-medium text-gray-900">{user?.full_name}</p>
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-500">E-mail</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Mail className="w-4 h-4 text-gray-400" />
                    <p className="font-medium text-gray-900">{user?.email}</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    O e-mail não pode ser alterado
                  </p>
                </div>

                <div>
                  <Label className="text-sm text-gray-500">Nível de Acesso</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Shield className="w-4 h-4 text-gray-400" />
                    <Badge className={nivelAcessoColors[user?.nivel_acesso || 'visualizador']}>
                      {nivelAcessoLabels[user?.nivel_acesso || 'visualizador']}
                    </Badge>
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-500">Função</Label>
                  <p className="font-medium text-gray-900 mt-1">
                    {user?.role === 'admin' ? 'Administrador' : 'Usuário'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Alteração de Senha */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-orange-600" />
                Alterar Senha
              </CardTitle>
              <CardDescription>
                Para alterar sua senha, use a opção "Esqueci minha senha" na tela de login
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Importante:</strong> Por motivos de segurança, a alteração de senha deve ser feita através do fluxo de redefinição de senha. 
                  Faça logout e clique em "Esqueci minha senha" na tela de login.
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Mensagem de Sucesso */}
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>Senha alterada com sucesso!</span>
          </motion.div>
        )}
      </div>
    </div>
  );
}