import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShoppingCart, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import ProductCard from "../components/products/ProductCard";
import CartDialog from "../components/products/CartDialog";
import AddProductDialog from "../components/products/AddProductDialog";
import EditProductDialog from "../components/products/EditProductDialog";

const categoryNames = {
  hortalicas: "Hortaliças",
  proteinas: "Proteínas",
  cereais: "Cereais",
  laticinios: "Laticínios",
  temperos: "Temperos e Condimentos",
  bebidas: "Bebidas",
  limpeza: "Limpeza e Higiene",
  descartaveis: "Descartáveis e Embalagens",
};

export default function ProductList() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get("category");

  // Carregar carrinho do localStorage ao iniciar
  const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem('purchaseCart');
    return savedCart ? JSON.parse(savedCart) : [];
  });
  
  const [showCart, setShowCart] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showEditProduct, setShowEditProduct] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  // Salvar carrinho no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('purchaseCart', JSON.stringify(cart));
  }, [cart]);

  const { data: products, isLoading } = useQuery({
    queryKey: ['products', category],
    queryFn: () => base44.entities.Product.filter({ category, is_active: true }),
    initialData: [],
    enabled: !!category,
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const addToCart = (product, quantity) => {
    const existingItem = cart.find(item => item.product_id === product.id);
    
    if (existingItem) {
      setCart(cart.map(item => 
        item.product_id === product.id 
          ? { ...item, quantity: item.quantity + quantity }
          : item
      ));
    } else {
      setCart([...cart, {
        product_id: product.id,
        product_name: product.name,
        product_category: product.category,
        quantity: quantity,
        unit: product.unit,
      }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.product_id !== productId));
  };

  const updateCartQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(cart.map(item => 
        item.product_id === productId 
          ? { ...item, quantity }
          : item
      ));
    }
  };

  const clearCart = () => {
    setCart([]);
    localStorage.removeItem('purchaseCart');
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setShowEditProduct(true);
  };

  const handleCloseEdit = () => {
    setShowEditProduct(false);
    setEditingProduct(null);
  };

  const handleEditSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['products'] });
    handleCloseEdit();
  };

  if (!category) {
    return (
      <div className="p-8">
        <p className="text-center text-gray-600">Categoria não encontrada</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="hover:bg-orange-100"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                {categoryNames[category]}
              </h1>
              <p className="text-gray-600 mt-1">
                Adicione produtos ao carrinho
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={() => setShowAddProduct(true)}
              variant="outline"
              className="hover:bg-blue-50"
            >
              <Plus className="w-4 h-4 mr-2" />
              Cadastrar
            </Button>

            <Button
              onClick={() => setShowCart(true)}
              className="relative bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              Carrinho
              {cart.length > 0 && (
                <Badge className="ml-2 bg-white text-orange-600">
                  {cart.length}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {Array(10).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-md h-48 animate-pulse" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-orange-100 p-12 text-center">
            <p className="text-gray-600 text-lg mb-4">
              Nenhum produto cadastrado nesta categoria ainda
            </p>
            <Button onClick={() => setShowAddProduct(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Cadastrar Primeiro Produto
            </Button>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
          >
            <AnimatePresence>
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={addToCart}
                  onEdit={handleEditProduct}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      {/* Cart Dialog */}
      <CartDialog
        open={showCart}
        onClose={() => setShowCart(false)}
        cart={cart}
        user={user}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeFromCart}
        onClearCart={clearCart}
      />

      {/* Add Product Dialog */}
      <AddProductDialog
        open={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        category={category}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['products'] });
          setShowAddProduct(false);
        }}
      />

      {/* Edit Product Dialog */}
      <EditProductDialog
        open={showEditProduct}
        onClose={handleCloseEdit}
        product={editingProduct}
        onSuccess={handleEditSuccess}
      />
    </div>
  );
}