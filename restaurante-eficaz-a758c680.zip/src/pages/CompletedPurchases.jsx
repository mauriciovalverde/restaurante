import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Search, Calendar, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import CompletedPurchaseCard from "../components/requests/CompletedPurchaseCard";
import EmptyState from "../components/requests/EmptyState";
import AddProductDialog from "../components/products/AddProductDialog";

export default function CompletedPurchases() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const queryClient = useQueryClient();

  const { data: requests, isLoading } = useQuery({
    queryKey: ['purchaseRequests', 'concluido'],
    queryFn: () => base44.entities.PurchaseRequest.filter({ status: 'concluido' }, '-completed_date'),
    initialData: [],
  });

  const filteredRequests = requests.filter(request => {
    const matchesSearch = searchQuery === "" || 
      request.requester_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.completed_by_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.items?.some(item => 
        item.product_name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesSearch;
  });

  const groupedByDate = filteredRequests.reduce((groups, request) => {
    const date = format(new Date(request.completed_date), 'yyyy-MM-dd');
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(request);
    return groups;
  }, {});

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              Compras Concluídas
            </h1>
            <p className="text-gray-600">
              Histórico de todas as compras realizadas
            </p>
          </div>

          <Button
            onClick={() => setShowAddProduct(true)}
            variant="outline"
            className="hover:bg-blue-50"
          >
            <Plus className="w-4 h-4 mr-2" />
            Cadastrar Produto
          </Button>
        </div>

        {/* Search */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-orange-100 p-6 mb-6">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar por produto, solicitante ou comprador..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Completed Requests List */}
        {isLoading ? (
          <div className="grid gap-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-md h-32 animate-pulse" />
            ))}
          </div>
        ) : filteredRequests.length === 0 ? (
          <EmptyState 
            message={searchQuery ? "Nenhuma compra encontrada" : "Nenhuma compra concluída ainda"}
            description={searchQuery ? "Tente buscar por outro termo" : "As compras concluídas aparecerão aqui"}
          />
        ) : (
          <div className="space-y-8">
            <AnimatePresence>
              {Object.keys(groupedByDate).sort().reverse().map((date) => (
                <motion.div
                  key={date}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <Calendar className="w-5 h-5 text-orange-600" />
                    <h2 className="text-lg font-semibold text-gray-900">
                      {format(new Date(date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                    </h2>
                    <div className="flex-1 h-px bg-orange-200" />
                  </div>
                  
                  <div className="grid gap-4">
                    {groupedByDate[date].map((request) => (
                      <CompletedPurchaseCard
                        key={request.id}
                        request={request}
                      />
                    ))}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>

      <AddProductDialog
        open={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['products'] });
          setShowAddProduct(false);
        }}
      />
    </div>
  );
}