
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, ShoppingCart, CheckCircle2, LogOut, Menu, ChefHat, Home, ArrowLeft, Users, User as UserIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import ProtectedRoute from "@/components/auth/ProtectedRoute";

const navigationItems = [
  {
    title: "Início",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Pendentes",
    url: createPageUrl("PurchaseRequests"),
    icon: ShoppingCart,
  },
  {
    title: "Concluídas",
    url: createPageUrl("CompletedPurchases"),
    icon: CheckCircle2,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();

  // Não aplicar ProtectedRoute se estiver na página de aprovação
  const isAwaitingApprovalPage = currentPageName === "AwaitingApproval";

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: pendingRequests } = useQuery({
    queryKey: ['pendingCount'],
    queryFn: () => base44.entities.PurchaseRequest.filter({ status: 'pendente' }),
    initialData: [],
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  const isHomePage = location.pathname === createPageUrl("Dashboard");
  const isAdmin = user?.nivel_acesso === "admin";

  // Se estiver na página de aguardando aprovação, não mostrar o layout completo
  if (isAwaitingApprovalPage) {
    return children;
  }

  return (
    <ProtectedRoute>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
          <Sidebar className="border-r border-orange-100 bg-white/80 backdrop-blur-sm">
            <SidebarHeader className="border-b border-orange-100 p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg">
                  <ChefHat className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-gray-900 text-lg">Painel de Compras</h2>
                  <p className="text-xs text-orange-600">Restaurante</p>
                </div>
              </div>
            </SidebarHeader>
            
            <SidebarContent className="p-3">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
                  Menu
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {navigationItems.map((item) => {
                      const isActive = location.pathname === item.url;
                      const isPending = item.title === "Pendentes";
                      const pendingCount = pendingRequests?.length || 0;
                      
                      return (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton 
                            asChild 
                            className={`hover:bg-orange-50 hover:text-orange-700 transition-all duration-200 rounded-lg mb-1 ${
                              isActive ? 'bg-orange-100 text-orange-700 font-semibold' : ''
                            }`}
                          >
                            <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                              <item.icon className="w-5 h-5" />
                              <span>{item.title}</span>
                              {isPending && pendingCount > 0 && (
                                <Badge className="ml-auto bg-orange-500 text-white">
                                  {pendingCount}
                                </Badge>
                              )}
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      );
                    })}
                    
                    {/* Menu Admin - só para admin */}
                    {isAdmin && (
                      <SidebarMenuItem>
                        <SidebarMenuButton 
                          asChild 
                          className={`hover:bg-purple-50 hover:text-purple-700 transition-all duration-200 rounded-lg mb-1 ${
                            location.pathname === createPageUrl("AdminPanel") ? 'bg-purple-100 text-purple-700 font-semibold' : ''
                          }`}
                        >
                          <Link to={createPageUrl("AdminPanel")} className="flex items-center gap-3 px-3 py-2.5">
                            <Users className="w-5 h-5" />
                            <span>Admin</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    )}

                    {/* Menu Perfil */}
                    <SidebarMenuItem>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-lg mb-1 ${
                          location.pathname === createPageUrl("Profile") ? 'bg-blue-100 text-blue-700 font-semibold' : ''
                        }`}
                      >
                        <Link to={createPageUrl("Profile")} className="flex items-center gap-3 px-3 py-2.5">
                          <UserIcon className="w-5 h-5" />
                          <span>Perfil</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-orange-100 p-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 px-2">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-amber-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-semibold text-sm">
                      {user?.full_name?.[0]?.toUpperCase() || 'U'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {user?.full_name || 'Usuário'}
                    </p>
                    <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                    <Badge className="mt-1 text-xs" variant="outline">
                      {user?.nivel_acesso || 'visualizador'}
                    </Badge>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleLogout}
                  className="w-full justify-start gap-2 hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                >
                  <LogOut className="w-4 h-4" />
                  Sair
                </Button>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-white/80 backdrop-blur-sm border-b border-orange-100 px-4 md:px-6 py-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <SidebarTrigger className="md:hidden hover:bg-orange-100 p-2 rounded-lg transition-colors duration-200">
                    <Menu className="w-5 h-5" />
                  </SidebarTrigger>
                  <h1 className="text-xl md:text-2xl font-bold text-orange-600 uppercase tracking-wide">
                    PAINEL DE COMPRAS
                  </h1>
                </div>

                <div className="flex items-center gap-2">
                  {!isHomePage && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(-1)}
                      className="text-gray-600 hover:text-orange-600 hover:bg-orange-50 text-xs"
                    >
                      <ArrowLeft className="w-3 h-3 mr-1" />
                      RETORNAR
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(createPageUrl("Dashboard"))}
                    className="text-gray-600 hover:text-orange-600 hover:bg-orange-50 text-xs"
                  >
                    <Home className="w-3 h-3 mr-1" />
                    HOME
                  </Button>
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </ProtectedRoute>
  );
}
