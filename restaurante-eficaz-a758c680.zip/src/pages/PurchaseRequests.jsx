import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import PurchaseRequestCard from "../components/requests/PurchaseRequestCard";
import EmptyState from "../components/requests/EmptyState";
import AddProductDialog from "../components/products/AddProductDialog";

export default function PurchaseRequests() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddProduct, setShowAddProduct] = useState(false);
  const queryClient = useQueryClient();

  const { data: requests, isLoading } = useQuery({
    queryKey: ['purchaseRequests', 'pendente'],
    queryFn: () => base44.entities.PurchaseRequest.filter({ status: 'pendente' }, '-created_date'),
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const completeMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PurchaseRequest.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchaseRequests'] });
      queryClient.invalidateQueries({ queryKey: ['pendingCount'] });
    },
  });

  const handleComplete = async (request) => {
    await completeMutation.mutateAsync({
      id: request.id,
      data: {
        status: 'concluido',
        completed_date: new Date().toISOString(),
        completed_by_name: user?.full_name,
        completed_by_email: user?.email,
      }
    });
  };

  const filteredRequests = requests.filter(request => {
    const matchesSearch = searchQuery === "" || 
      request.requester_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.items?.some(item => 
        item.product_name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesSearch;
  });

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              Solicitações Pendentes
            </h1>
            <p className="text-gray-600">
              Gerencie as solicitações de compra da equipe
            </p>
          </div>

          <Button
            onClick={() => setShowAddProduct(true)}
            variant="outline"
            className="hover:bg-blue-50"
          >
            <Plus className="w-4 h-4 mr-2" />
            Cadastrar Produto
          </Button>
        </div>

        {/* Search */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-orange-100 p-6 mb-6">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar produto ou solicitante..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Requests List */}
        {isLoading ? (
          <div className="grid gap-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-md h-32 animate-pulse" />
            ))}
          </div>
        ) : filteredRequests.length === 0 ? (
          <EmptyState 
            message={searchQuery ? "Nenhuma solicitação encontrada" : "Nenhuma solicitação pendente"}
            description={searchQuery ? "Tente buscar por outro termo" : "Quando houver novas solicitações, elas aparecerão aqui"}
          />
        ) : (
          <motion.div layout className="grid gap-4">
            <AnimatePresence>
              {filteredRequests.map((request) => (
                <PurchaseRequestCard
                  key={request.id}
                  request={request}
                  onComplete={handleComplete}
                  isCompleting={completeMutation.isPending}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      <AddProductDialog
        open={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ['products'] });
          setShowAddProduct(false);
        }}
      />
    </div>
  );
}