import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Shield, Edit2, UserPlus } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function AdminPanel() {
  const queryClient = useQueryClient();
  const [editingUser, setEditingUser] = useState(null);
  const [newLevel, setNewLevel] = useState("");

  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: allUsers, isLoading } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list('-created_date'),
    initialData: [],
  });

  const updateUserLevelMutation = useMutation({
    mutationFn: ({ userId, nivel_acesso }) => 
      base44.entities.User.update(userId, { nivel_acesso }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allUsers'] });
      setEditingUser(null);
      setNewLevel("");
    },
  });

  const handleEditLevel = (user) => {
    setEditingUser(user);
    setNewLevel(user.nivel_acesso || 'visualizador');
  };

  const handleSaveLevel = () => {
    if (editingUser && newLevel) {
      updateUserLevelMutation.mutate({
        userId: editingUser.id,
        nivel_acesso: newLevel,
      });
    }
  };

  const nivelAcessoLabels = {
    admin: "Administrador",
    coordenador: "Coordenador",
    parceiro: "Parceiro",
    visualizador: "Visualizador",
  };

  const nivelAcessoColors = {
    admin: "bg-purple-100 text-purple-800 border-purple-200",
    coordenador: "bg-blue-100 text-blue-800 border-blue-200",
    parceiro: "bg-green-100 text-green-800 border-green-200",
    visualizador: "bg-gray-100 text-gray-800 border-gray-200",
  };

  // Separar usuários pendentes (sem nivel_acesso) e aprovados (com nivel_acesso)
  const pendingUsers = allUsers.filter(user => !user.nivel_acesso);
  const approvedUsers = allUsers.filter(user => user.nivel_acesso);

  // Verificar se o usuário atual é admin
  if (currentUser?.nivel_acesso !== 'admin') {
    return (
      <div className="min-h-screen p-8 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                Acesso Negado
              </h2>
              <p className="text-gray-600">
                Apenas administradores podem acessar esta área.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Painel Administrativo
          </h1>
          <p className="text-gray-600">
            Gerencie usuários e permissões do sistema
          </p>
        </div>

        {/* Usuários Pendentes de Aprovação */}
        {pendingUsers.length > 0 && (
          <Card className="border-orange-200 bg-orange-50/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-orange-600" />
                Usuários Aguardando Aprovação
                <Badge className="ml-auto bg-orange-500 text-white">{pendingUsers.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingUsers.map((user) => (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between p-4 bg-white rounded-lg border-2 border-orange-200"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-gray-900">{user.full_name}</p>
                        <Badge className="bg-orange-100 text-orange-800">Pendente</Badge>
                        {user.role === 'admin' && (
                          <Badge className="bg-red-100 text-red-800">Sistema Admin</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{user.email}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Cadastrado em: {format(new Date(user.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleEditLevel(user)}
                      disabled={updateUserLevelMutation.isPending}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <UserPlus className="w-3 h-3 mr-1" />
                      Aprovar Acesso
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lista de Usuários Aprovados */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-orange-600" />
              Usuários Aprovados
              <Badge className="ml-auto">{approvedUsers.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-gray-500">Carregando...</p>
            ) : approvedUsers.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                Nenhum usuário aprovado ainda
              </p>
            ) : (
              <div className="space-y-3">
                {approvedUsers.map((user) => (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-gray-900">{user.full_name}</p>
                        <Badge className={nivelAcessoColors[user.nivel_acesso]}>
                          {nivelAcessoLabels[user.nivel_acesso]}
                        </Badge>
                        {user.role === 'admin' && (
                          <Badge className="bg-red-100 text-red-800">Sistema Admin</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{user.email}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Cadastrado em: {format(new Date(user.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditLevel(user)}
                      disabled={updateUserLevelMutation.isPending}
                      className="hover:bg-blue-50 hover:border-blue-300"
                    >
                      <Edit2 className="w-3 h-3 mr-1" />
                      Editar Nível
                    </Button>
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Dialog para Editar Nível */}
        <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingUser?.nivel_acesso ? 'Alterar Nível de Acesso' : 'Aprovar Usuário'}
              </DialogTitle>
              <DialogDescription>
                {editingUser?.nivel_acesso 
                  ? `Edite o nível de acesso de ${editingUser?.full_name}`
                  : `Defina o nível de acesso para ${editingUser?.full_name}`
                }
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Nível de Acesso
                </label>
                <Select value={newLevel} onValueChange={setNewLevel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o nível de acesso" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">
                      <div className="flex items-center gap-2">
                        <span>Administrador</span>
                        <span className="text-xs text-gray-500">- Acesso total</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="coordenador">
                      <div className="flex items-center gap-2">
                        <span>Coordenador</span>
                        <span className="text-xs text-gray-500">- Gestão de conteúdo</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="parceiro">
                      <div className="flex items-center gap-2">
                        <span>Parceiro</span>
                        <span className="text-xs text-gray-500">- Pode enviar sugestões</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="visualizador">
                      <div className="flex items-center gap-2">
                        <span>Visualizador</span>
                        <span className="text-xs text-gray-500">- Apenas leitura</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setEditingUser(null)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSaveLevel}
                disabled={updateUserLevelMutation.isPending || !newLevel}
                className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
              >
                {updateUserLevelMutation.isPending ? "Salvando..." : editingUser?.nivel_acesso ? "Salvar" : "Aprovar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}