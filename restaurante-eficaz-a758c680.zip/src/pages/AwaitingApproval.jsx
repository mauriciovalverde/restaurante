import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, ChefHat, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

export default function AwaitingApproval() {
  const { data: user, refetch } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    refetchInterval: 5000, // Verifica a cada 5 segundos se foi aprovado
  });

  const handleLogout = () => {
    base44.auth.logout();
  };

  const handleRefresh = () => {
    refetch();
  };

  // Se o usuário foi aprovado, recarregar a página
  if (user?.nivel_acesso) {
    window.location.reload();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md"
      >
        <Card className="shadow-2xl border-2 border-orange-200">
          <CardHeader className="text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-amber-600 rounded-full flex items-center justify-center mx-auto shadow-lg">
              <ChefHat className="w-12 h-12 text-white" />
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Aguardando Aprovação
              </CardTitle>
              <CardDescription className="text-base mt-2">
                Seu cadastro está sendo revisado
              </CardDescription>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="bg-orange-50 rounded-lg p-6 border border-orange-200">
              <div className="flex items-start gap-3">
                <Clock className="w-6 h-6 text-orange-600 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Seu acesso está pendente
                  </h3>
                  <p className="text-sm text-gray-700 mb-2">
                    Olá, <strong>{user?.full_name}</strong>!
                  </p>
                  <p className="text-sm text-gray-700 mb-2">
                    Seu cadastro foi recebido com sucesso. Um administrador do sistema está revisando sua solicitação e em breve você receberá acesso.
                  </p>
                  <p className="text-sm text-gray-600">
                    Email cadastrado: <strong>{user?.email}</strong>
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleRefresh}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Verificar Aprovação
              </Button>

              <Button
                variant="outline"
                onClick={handleLogout}
                className="w-full"
              >
                Sair
              </Button>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <p className="text-xs text-blue-800 text-center">
                <strong>Dica:</strong> Esta página verifica automaticamente a cada 5 segundos se você foi aprovado. Você não precisa fazer nada, apenas aguardar.
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}