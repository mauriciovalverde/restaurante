import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Plus, Package, Pencil } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function ProductCard({ product, onAddToCart, onEdit }) {
  const [quantity, setQuantity] = useState(1);

  const handleAdd = () => {
    if (quantity > 0) {
      onAddToCart(product, parseFloat(quantity));
      setQuantity(1);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 relative group"
    >
      {/* Edit Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => onEdit(product)}
        className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 hover:bg-white h-7 w-7"
      >
        <Pencil className="w-3 h-3 text-blue-600" />
      </Button>

      {/* Small Icon */}
      <div className="flex items-center justify-center p-3 bg-gradient-to-br from-gray-50 to-gray-100">
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.name}
            className="w-12 h-12 object-cover rounded-lg"
          />
        ) : (
          <Package className="w-12 h-12 text-gray-400" />
        )}
      </div>

      {/* Content */}
      <div className="p-3 space-y-2">
        <h3 className="font-semibold text-gray-900 text-sm line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>

        <div className="flex items-center gap-1">
          <Input
            type="number"
            min="0"
            step="0.5"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            className="h-8 text-sm"
            placeholder="Qtd"
          />
          <span className="text-xs text-gray-500 whitespace-nowrap">{product.unit}</span>
        </div>

        <Button
          onClick={handleAdd}
          size="sm"
          className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white h-8 text-xs"
        >
          <Plus className="w-3 h-3 mr-1" />
          Adicionar
        </Button>
      </div>
    </motion.div>
  );
}