import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingCart, X, Trash2, Send, MapPin } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function CartDialog({ 
  open, 
  onClose, 
  cart, 
  user, 
  onUpdateQuantity, 
  onRemoveItem,
  onClearCart 
}) {
  const [notes, setNotes] = useState("");
  const [location, setLocation] = useState("RESTAURANTE DA BARRA");
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PurchaseRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchaseRequests'] });
      queryClient.invalidateQueries({ queryKey: ['pendingCount'] });
      onClearCart();
      setNotes("");
      setLocation("RESTAURANTE DA BARRA");
      onClose();
    },
  });

  const handleSubmit = () => {
    if (cart.length === 0 || !user || !location) return;

    createMutation.mutate({
      location,
      items: cart,
      status: 'pendente',
      requester_name: user.full_name,
      requester_email: user.email,
      notes: notes || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <ShoppingCart className="w-5 h-5 text-orange-600" />
            Carrinho de Compras
            {cart.length > 0 && (
              <span className="text-sm font-normal text-gray-500">
                ({cart.length} {cart.length === 1 ? 'item' : 'itens'})
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        {cart.length === 0 ? (
          <div className="py-12 text-center">
            <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">Seu carrinho está vazio</p>
            <p className="text-sm text-gray-400 mt-2">Adicione produtos para fazer um pedido</p>
          </div>
        ) : (
          <>
            {/* Location Selection */}
            <div className="bg-orange-50 rounded-lg p-4 border-2 border-orange-200">
              <Label htmlFor="location" className="flex items-center gap-2 mb-2 font-semibold text-gray-900">
                <MapPin className="w-4 h-4 text-orange-600" />
                Destino do Pedido
                <span className="text-red-500">*</span>
              </Label>
              <Select value={location} onValueChange={setLocation} required>
                <SelectTrigger id="location" className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="RESTAURANTE DA BARRA">RESTAURANTE DA BARRA</SelectItem>
                  <SelectItem value="COMÉRCIO">COMÉRCIO</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Cart Items */}
            <ScrollArea className="max-h-[300px] pr-4">
              <div className="space-y-3">
                {cart.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 text-sm">
                        {item.product_name}
                      </h4>
                      <p className="text-xs text-gray-500">{item.product_category}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min="0"
                        step="0.5"
                        value={item.quantity}
                        onChange={(e) => onUpdateQuantity(item.product_id, parseFloat(e.target.value))}
                        className="w-20 h-8 text-sm"
                      />
                      <span className="text-xs text-gray-500 w-12">{item.unit}</span>
                    </div>

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRemoveItem(item.product_id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 h-8 w-8"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Observações (opcional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Adicione observações sobre este pedido..."
                className="resize-none"
                rows={3}
              />
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClearCart}
                disabled={createMutation.isPending}
                className="text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Limpar Carrinho
              </Button>
              <Button
                type="button"
                onClick={handleSubmit}
                disabled={createMutation.isPending || cart.length === 0 || !location}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              >
                <Send className="w-4 h-4 mr-2" />
                {createMutation.isPending ? "Enviando..." : "Finalizar Pedido"}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}