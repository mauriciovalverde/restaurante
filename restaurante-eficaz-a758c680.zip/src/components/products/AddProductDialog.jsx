import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";

const categories = [
  { value: "hortalicas", label: "Hortaliças" },
  { value: "proteinas", label: "Proteínas" },
  { value: "cereais", label: "Cereais" },
  { value: "laticinios", label: "Laticínios" },
  { value: "temperos", label: "Temperos" },
  { value: "bebidas", label: "Bebidas" },
  { value: "limpeza", label: "Limpeza" },
  { value: "descartaveis", label: "Descartáveis" },
];

const units = [
  { value: "kg", label: "Kg" },
  { value: "unidade", label: "Unidade" },
  { value: "pacote", label: "Pacote" },
  { value: "litro", label: "Litro" },
  { value: "caixa", label: "Caixa" },
  { value: "duzia", label: "Dúzia" },
];

export default function AddProductDialog({ open, onClose, category, onSuccess }) {
  const [name, setName] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(category || "");
  const [unit, setUnit] = useState("unidade");
  const [imageUrl, setImageUrl] = useState("");

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Product.create(data),
    onSuccess: () => {
      setName("");
      setSelectedCategory(category || "");
      setUnit("unidade");
      setImageUrl("");
      onSuccess();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!name || !selectedCategory) return;

    createMutation.mutate({
      name,
      category: selectedCategory,
      unit,
      image_url: imageUrl || undefined,
      is_active: true,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Plus className="w-5 h-5 text-blue-600" />
            Cadastrar Novo Produto
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="name">
                Nome do Produto
                <span className="text-red-500 ml-1">*</span>
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Tomate, Arroz Branco 5kg..."
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="category">
                Categoria
                <span className="text-red-500 ml-1">*</span>
              </Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory} required>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="unit">
                Unidade de Medida
                <span className="text-red-500 ml-1">*</span>
              </Label>
              <Select value={unit} onValueChange={setUnit} required>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {units.map((u) => (
                    <SelectItem key={u.value} value={u.value}>
                      {u.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="imageUrl">URL da Imagem (opcional)</Label>
              <Input
                id="imageUrl"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://exemplo.com/imagem.jpg"
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                Cole o link de uma imagem do Unsplash ou outra fonte
              </p>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={createMutation.isPending}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={createMutation.isPending || !name || !selectedCategory}
              className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
            >
              {createMutation.isPending ? "Cadastrando..." : "Cadastrar Produto"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}