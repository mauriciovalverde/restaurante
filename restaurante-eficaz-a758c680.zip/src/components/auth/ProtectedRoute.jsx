import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProtectedRoute({ children, requiredLevel = null }) {
  const navigate = useNavigate();
  
  const { data: user, isLoading, error } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && (error || !user)) {
      // Usuário não autenticado, redirecionar para login
      base44.auth.redirectToLogin();
    }
  }, [user, isLoading, error, navigate]);

  // Verificar se usuário foi aprovado (tem nivel_acesso)
  useEffect(() => {
    if (user && !user.nivel_acesso) {
      // Usuário autenticado mas ainda não aprovado
      navigate(createPageUrl("AwaitingApproval"));
    }
  }, [user, navigate]);

  // Verificar nível de acesso se requerido
  useEffect(() => {
    if (user && user.nivel_acesso && requiredLevel) {
      const levels = ["visualizador", "parceiro", "coordenador", "admin"];
      const userLevelIndex = levels.indexOf(user.nivel_acesso);
      const requiredLevelIndex = levels.indexOf(requiredLevel);
      
      if (userLevelIndex < requiredLevelIndex) {
        // Usuário não tem permissão suficiente
        navigate(createPageUrl("Dashboard"));
      }
    }
  }, [user, requiredLevel, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Verificando autenticação...</p>
        </div>
      </div>
    );
  }

  if (error || !user) {
    return null; // Redirecionamento acontecerá no useEffect
  }

  // Se não tem nivel_acesso, será redirecionado no useEffect
  if (!user.nivel_acesso) {
    return null;
  }

  return children;
}