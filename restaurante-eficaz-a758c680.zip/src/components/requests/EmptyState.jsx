import { ShoppingBasket } from "lucide-react";

export default function EmptyState({ message, description }) {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-orange-100 p-12 text-center">
      <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
        <ShoppingBasket className="w-10 h-10 text-orange-600" />
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">
        {message}
      </h3>
      <p className="text-gray-600">
        {description}
      </p>
    </div>
  );
}