import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, User, Calendar, MessageSquare, Package, MapPin } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function PurchaseRequestCard({ request, onComplete, isCompleting }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 p-6 border-l-4 border-orange-500"
    >
      <div className="flex flex-col md:flex-row gap-6">
        {/* Main Info */}
        <div className="flex-1 space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Pedido de Compras
              </h3>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className="bg-orange-100 text-orange-800">
                  {request.items?.length || 0} {request.items?.length === 1 ? 'item' : 'itens'}
                </Badge>
                <Badge className={`${
                  request.location === "RESTAURANTE DA BARRA" 
                    ? "bg-blue-100 text-blue-800 border-blue-200" 
                    : "bg-purple-100 text-purple-800 border-purple-200"
                }`}>
                  <MapPin className="w-3 h-3 mr-1" />
                  {request.location}
                </Badge>
              </div>
            </div>
          </div>

          {/* Items List */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <div className="flex items-center gap-2 mb-3">
              <Package className="w-4 h-4 text-gray-600" />
              <h4 className="font-semibold text-gray-900 text-sm">Lista de Produtos:</h4>
            </div>
            <div className="space-y-2">
              {request.items?.map((item, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="text-gray-700">• {item.product_name}</span>
                  <span className="font-medium text-gray-900">
                    {item.quantity} {item.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2 text-gray-600">
              <User className="w-4 h-4" />
              <span>Solicitado por: <strong>{request.requester_name}</strong></span>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>
                {format(new Date(request.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
              </span>
            </div>
          </div>

          {request.notes && (
            <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
              <div className="flex items-start gap-2">
                <MessageSquare className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-700">{request.notes}</p>
              </div>
            </div>
          )}
        </div>

        {/* Action Button */}
        <div className="flex items-center md:items-start">
          <Button
            onClick={() => onComplete(request)}
            disabled={isCompleting}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-md w-full md:w-auto"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            {isCompleting ? "Concluindo..." : "Marcar como Comprado"}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}