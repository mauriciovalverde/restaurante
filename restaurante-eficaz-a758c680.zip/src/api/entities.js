import { base44 } from './base44Client';


export const Product = base44.entities.Product;

export const PurchaseRequest = base44.entities.PurchaseRequest;

export const AccessRequest = base44.entities.AccessRequest;

export const ApprovedUser = base44.entities.ApprovedUser;



// auth sdk:
export const User = base44.auth;